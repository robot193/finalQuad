import React from 'react'

import {
  CCard,
  CCardBody,
  CCardHeader,
  CCol,
  CRow,
} from '@coreui/react'



import WidgetsDropdown from '../widgets/WidgetsDropdown'

import {
  CChartBar,
  CChartDoughnut,
  CChartLine,
  CChartPie,
} from '@coreui/react-chartjs'
import { DocsLink } from '../../../src/components'
const Dashboard = () => {
 


  return (
    <>
      <WidgetsDropdown className="mb-4" />
      
      <CRow>
        <CCol xs={12}></CCol>
        <CCol xs={6}>
          <CCard className="mb-4">
            <CCardHeader>
            Total Volume of Waste Collected 
            </CCardHeader>
            <CCardBody>
              <CChartBar
                data={{
                  labels: ['Battery Disposal', 'Desktop Recycling', 'Laptop Recycling', 'Miscellaneous', 'Mobile Phone Recycling', 'Printer Recycling', 'TV Recycling'],
                  datasets: [
                    {
                      label: 'Total Volume of Waste Collected',
                      backgroundColor: '#074211',
                      data: ['197.44', '191.74', '311.89', '285.8', '244.61', '272.61', '248.12'],
                    },
                  ],
                }}
                labels="months"
              />
            </CCardBody>
          </CCard>
        </CCol>

        <CCol xs={6}>
          <CCard className="mb-4">
            <CCardHeader>
            Reduction in Carbon Emissions and Greenhouse Gas (GHG) Emissions across weeks <DocsLink name="chart" />
            </CCardHeader>
            <CCardBody>
              <CChartLine
                data={{
                  labels: ['Week 1', 'Week 2', 'Week 3', 'Week 4', 'Week 5'],
                  datasets: [
                    {
                      label: 'Green House Gas Emissions Reduced (kg CO₂e)',
                      backgroundColor: 'rgba(220, 220, 220, 0.2)',
                      borderColor: 'rgba(41, 70, 15, 1)',
                      pointBackgroundColor: 'rgba(41, 70, 15, 1)',
                      pointBorderColor: '#fff',
                      data: ['1103.78', '809.25', '961.83', '1225.98', '460.4'],
                    },
                    {
                      label: 'Carbon Emissions Reduced (kg)',
                      backgroundColor: 'rgba(74, 167, 51, 0.2)',
                      borderColor: 'rgba(74, 167, 51, 1)',
                      pointBackgroundColor: 'rgba(74, 167, 51, 1)',
                      pointBorderColor: '#fff',
                      data: ['807.16', '789.8', '687.13', '996.27','327.5'],
                    },
                  ],
                }}
              />
            </CCardBody> 
        </CCard>
        </CCol>


        <CCol xs={6}>
          <CCard className="mb-4">
            <CCardHeader>
            Weekly Job Completion Trend
            </CCardHeader>
            <CCardBody>
              <CChartLine
                data={{
                  labels: ['Week 1', 'Week 2', 'Week 3', 'Week 4', 'Week 5'],
                  datasets: [
                    {
                      label:'Weekly Job Completion Trend',
                      backgroundColor: '#97d1af',
                      borderColor: 'rgba(41, 70, 15, 1)',
                      pointBackgroundColor: '#97d1af',
                      pointBorderColor: '#fff',
                      data: [20,20,22,28,10],
                    }
                  ],
                }}
              />
            </CCardBody> 
        </CCard>
        </CCol>

        <CCol xs={6}>
          <CCard className="mb-4">
            <CCardHeader>
            Total Volume of Waste Collected by Category across weeks <DocsLink name="chart" />
            </CCardHeader>
            <CCardBody>
              <CChartBar
                data={{
                  labels: ['Week 1', 'Week 2', 'Week 3', 'Week 4', 'Week 5'],
                  datasets: [
                    {
                      label: 'Large',
                      backgroundColor: '#0e660c',
                      data: ['107.44', '165.74', '57.89', '85.8'],
                    },
                    {
                      label: 'Medium',
                      backgroundColor: '#82d580',
                      data: ['218.44', '183.74', '270.89', '384.8','170'],
                    },
                    {
                      label: 'Small',
                      backgroundColor: '#d0f5cf',
                      data: ['24.44', '40.74', '43.89', '43.8'],
                    },
                  ],
                }}
                options={{
                  scales: {
                  x: {
                    stacked: true,
                  },
                  y: {
                    stacked: true
                  }
                }
                }}
                labels="months"
              />
            </CCardBody>
          </CCard>
        </CCol>


        <CCol xs={6}>
          <CCard className="mb-4">
            <CCardHeader>
            Energy Conserved by each Service type in Week 4
            </CCardHeader>
            <CCardBody>
              <CChartBar
                data={{
                  labels: ['Battery Disposal', 'Desktop Recycling', 'Laptop Recycling', 'Miscellaneous', 'Mobile Phone Recycling', 'Printer Recycling', 'TV Recycling'],
                  datasets: [
                    {
                      label: 'Energy Conserved by each Service type in Week 4',
                      backgroundColor: '#074211',
                      data: ['397.44', '172.74', '520.89', '635.8', '326.61', '1008.61', '167.12'],
                    },
                  ],
                }}options={{
                  indexAxis: 'y',
                  maintainAspectRatio: false
                  }}
                labels="months"
              />
            </CCardBody>
          </CCard>
        </CCol>


        <CCol xs={6}>
          <CCard className="mb-4">
            <CCardHeader>
            Distribution of Disposal Fees
            </CCardHeader>
            <CCardBody>
              <CChartBar
                data={{
                  labels: ['5', '12', '19', '26', '33', '40', '47','54','61','68'],
                  datasets: [
                    {
                      label: 'Total Volume of Waste Collected',
                      backgroundColor: '#4aa733',
                      data: ['13.69', '35.2', '6.78', '70', '17', '23', '22','46','7','31','35','62'],
                    },
                  ],
                }}
                labels="months"
              />
            </CCardBody>
          </CCard>
        </CCol>

        <CCol xs={6}>
        <CCard className="mb-4">
          <CCardHeader>
          Percentage of Toxic Substances Safely Disposed by service type <DocsLink name="chart" />{' '}
          </CCardHeader>
          <CCardBody>
            <CChartPie
              data={{
                labels: ['Battery Disposal', 'Desktop Recycling', 'Laptop Recycling', 'Miscellaneous', 'Mobile Phone Recycling', 'Printer Recycling', 'TV Recycling'],
                datasets: [
                  {
                    data: [31, 37, 35,42,41,39,28],
                    backgroundColor: ['#709c5b', '#4da710', '#b2e8a0','#93c47d','#6aa84f','#274e13','#38761d'],
                    hoverBackgroundColor: ['#709c5b', '#4da710', '#b2e8a0','#93c47d','#6aa84f','#274e13','#38761d'],
                  },
                ],
              }}options={{datalabels: {
                display: true,
                color: 'white',
                font: {
                  weight: 'bold',
                },
              },}}
            />
          </CCardBody>
        </CCard>
      </CCol>



      <CCol xs={6}>
        <CCard className="mb-4">
          <CCardHeader>
          Percentage of Waste Category Distribution
          </CCardHeader>
          <CCardBody>
            <CChartDoughnut
              data={{
                labels: ['Large', 'Medium', 'Small'],
                datasets: [
                  {
                    backgroundColor: ['#709c5b', '#4da710', '#b2e8a0'],
                    data: [15, 64, 21],
                  },
                ],
              }}
            />
          </CCardBody>
        </CCard>
      </CCol>
      </CRow>
      {/* <WidgetsBrand className="mb-4" withCharts /> */}
      
    </>
  )
}

export default Dashboard
